/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import contracts.IDataService;
import com.mongodb.client.model.Filters;
import Modelo.Celular;
import org.bson.Document;
import org.bson.types.ObjectId;

/**
 * Comando para eliminar un celular.
 * Usa Memento para guardar el estado del celular antes de eliminarlo, permitiendo deshacer la acción.
 */
public class EliminarCelularCommand implements ICommand {
    private IDataService dataService;
    private ObjectId celularId;
    private Document memento; // Memento para guardar el estado del celular eliminado

    public EliminarCelularCommand(IDataService dataService, ObjectId celularId) {
        this.dataService = dataService;
        this.celularId = celularId;
    }

    @Override
    public void execute() {
        // Guardar el estado actual del celular antes de eliminarlo (Memento)
        Document doc = dataService.getCelularesCollection().find(Filters.eq("_id", celularId)).first();
        if (doc != null) {
            this.memento = doc;
            dataService.getCelularesCollection().deleteOne(Filters.eq("_id", celularId));
        } else {
            System.err.println("Celular no encontrado para eliminar.");
        }
    }

    @Override
    public void undo() {
        // Restaurar el estado del celular si se guardó un memento
        if (this.memento != null) {
            dataService.getCelularesCollection().insertOne(this.memento);
        }
    }
}