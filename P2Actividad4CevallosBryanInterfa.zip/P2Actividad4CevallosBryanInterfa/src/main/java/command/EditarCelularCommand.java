/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import contracts.IDataService;
import Modelo.Celular;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.types.ObjectId;

/**
 * Comando para editar un celular existente.
 * Usa Memento para guardar el estado anterior del celular, permitiendo deshacer la acción.
 */
public class EditarCelularCommand implements ICommand {
    private IDataService dataService;
    private ObjectId celularId;
    private Celular celularModificado;
    private int nuevaCantidad;
    private Document memento; // Memento para guardar el estado original del celular

    public EditarCelularCommand(IDataService dataService, ObjectId celularId, Celular celularModificado, int nuevaCantidad) {
        this.dataService = dataService;
        this.celularId = celularId;
        this.celularModificado = celularModificado;
        this.nuevaCantidad = nuevaCantidad;
    }

    @Override
    public void execute() {
        // Guardar el estado original del celular antes de modificarlo (Memento)
        Document originalDoc = dataService.getCelularesCollection().find(Filters.eq("_id", celularId)).first();
        if (originalDoc != null) {
            this.memento = originalDoc;
            
            // Crear el documento de actualización
            Document updateDoc = new Document("$set", new Document()
                    .append("nombre", celularModificado.getNombre())
                    .append("marca", celularModificado.getMarca())
                    .append("precio", celularModificado.getPrecio())
                    .append("ram", celularModificado.getRam())
                    .append("almacenamiento", celularModificado.getAlmacenamiento())
                    .append("color", celularModificado.getColor())
                    .append("sim", celularModificado.getSim())
                    .append("cantidad", nuevaCantidad));
            
            dataService.getCelularesCollection().updateOne(Filters.eq("_id", celularId), updateDoc);
        }
    }

    @Override
    public void undo() {
        // Restaurar el estado original usando el memento
        if (this.memento != null) {
            dataService.getCelularesCollection().replaceOne(Filters.eq("_id", celularId), this.memento);
        }
    }
}