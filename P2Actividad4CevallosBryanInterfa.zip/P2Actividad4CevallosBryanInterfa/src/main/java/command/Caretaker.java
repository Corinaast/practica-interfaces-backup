/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import java.util.Stack;

/**
 * La clase Caretaker gestiona las pilas de comandos para las operaciones de deshacer y rehacer.
 * Sabe cómo ejecutar un comando, guardarlo en el historial y restaurar el estado anterior.
 */
public class Caretaker {
    private Stack<ICommand> undoStack = new Stack<>();
    private Stack<ICommand> redoStack = new Stack<>();

    /**
     * Ejecuta un comando y lo guarda en la pila de deshacer.
     * @param command El comando a ejecutar.
     */
    public void executeCommand(ICommand command) {
        command.execute();
        undoStack.push(command);
        redoStack.clear(); // Limpia la pila de rehacer cada vez que se ejecuta un nuevo comando
    }

    /**
     * Deshace la última acción si la pila no está vacía.
     */
    public void undo() {
        if (!undoStack.isEmpty()) {
            ICommand command = undoStack.pop();
            command.undo();
            redoStack.push(command);
        }
    }

    /**
     * Rehace la última acción deshecha si la pila no está vacía.
     */
    public void redo() {
        if (!redoStack.isEmpty()) {
            ICommand command = redoStack.pop();
            command.execute(); // Rehacer es simplemente ejecutar el comando de nuevo
            undoStack.push(command);
        }
    }
}
