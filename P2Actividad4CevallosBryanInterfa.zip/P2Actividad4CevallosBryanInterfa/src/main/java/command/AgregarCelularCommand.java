/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import contracts.IDataService;
import Modelo.Celular;
import com.mongodb.client.model.Filters;
import org.bson.Document;

public class AgregarCelularCommand implements ICommand {
    private IDataService dataService;
    private Celular celular;
    private int cantidad;

    public AgregarCelularCommand(IDataService dataService, Celular celular, int cantidad) {
        this.dataService = dataService;
        this.celular = celular;
        this.cantidad = cantidad;
    }

    @Override
    public void execute() {
        Document celularDoc = celular.toDocument().append("cantidad", cantidad);
        dataService.getCelularesCollection().insertOne(celularDoc);
    }

    @Override
    public void undo() {
        dataService.getCelularesCollection().deleteOne(Filters.eq("nombre", celular.getNombre()));
    }
}