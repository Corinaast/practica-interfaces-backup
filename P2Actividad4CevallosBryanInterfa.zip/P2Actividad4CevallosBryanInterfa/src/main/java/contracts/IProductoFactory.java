/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package contracts;

import Modelo.Celular;

public interface IProductoFactory {
    Celular crearProducto(
        String nombre,
        String marca,
        double precio,
        String ram,
        String almacenamiento,
        String color,
        String sim
    );
}