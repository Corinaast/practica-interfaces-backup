
package contracts;

public interface IProducto {
 String getNombre() ;
 String getMarca() ;
 double getPrecio() ;
 String getRam() ;
 String getAlmacenamiento(); 
 String getColor() ;
 String getSim() ;
}