package contracts;

import Modelo.CarritoDeCompra;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import Modelo.Celular;
import Modelo.Usuario;
import Modelo.Compra;

public interface IDataService {
    MongoCollection<Document> getUsuariosCollection();
    MongoCollection<Document> getCelularesCollection();
    MongoCollection<Document> getComprasCollection();
    void insertarCelular(Celular celular);
    void insertarUsuario(Usuario usuario);
    void insertarCompra(CarritoDeCompra carrito, String idUsuario);
    // Agrega aquí cualquier otro método de tu clase Mongodb
}