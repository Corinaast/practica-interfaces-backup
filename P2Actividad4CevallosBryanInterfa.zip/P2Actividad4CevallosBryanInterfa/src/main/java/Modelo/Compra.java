package Modelo;

import org.bson.Document;

public class Compra {
    private String nombreUsuario;
    private Celular celular;
    private int cantidad;
    private double precio;
    private double preciototal;

    public Compra(String nombreUsuario, Celular celular, int cantidad, double precio, double preciototal) {
        this.nombreUsuario = nombreUsuario;
        this.celular = celular;
        this.cantidad = cantidad;
        this.precio = precio;
        this.preciototal = preciototal;
    }

   

    public Document toDocument() {
        return new Document("usuario", nombreUsuario)
                .append("celular", celular.toDocument())
                .append("cantidad", cantidad)
                .append("precio", precio)
                .append("Total", preciototal);
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public Celular getCelular() {
        return celular;
    }

    public int getCantidad() {
        return cantidad;
    }

   
}
