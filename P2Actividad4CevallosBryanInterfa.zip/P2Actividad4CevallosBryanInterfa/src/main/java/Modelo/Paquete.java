package Modelo;

import contracts.IProducto;
import java.util.ArrayList;
import java.util.List;

public class Paquete implements IProducto {
    private String nombre;
    private double descuento;
    private List<IProducto> productos = new ArrayList<>();

    public Paquete(String nombre, double descuento) {
        this.nombre = nombre;
        this.descuento = descuento;
    }

    public void agregar(IProducto producto) {
        productos.add(producto);
    }

    public void eliminar(IProducto producto) {
        productos.remove(producto);
    }

    @Override
    public double getPrecio() {
        double total = 0;
        for (IProducto producto : productos) {
            total += producto.getPrecio();
        }
        return total * (1 - descuento);
    }

    @Override
    public String getNombre() {
        return this.nombre;
    }
    
    // Los siguientes métodos no son relevantes para un paquete, 
    // pero deben ser implementados para cumplir con la interfaz.
    // Simplemente pueden devolver un valor por defecto o nulo.
    @Override
    public String getMarca() { return null; }
    @Override
    public String getRam() { return null; }
    @Override
    public String getAlmacenamiento() { return null; }
    @Override
    public String getColor() { return null; }
    @Override
    public String getSim() { return null; }
}