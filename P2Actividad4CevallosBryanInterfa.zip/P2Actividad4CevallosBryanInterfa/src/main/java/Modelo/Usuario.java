
package Modelo;

import org.bson.Document;

public class Usuario {
    protected String nombre;
    protected String edad;
    protected String correo;
    protected String password;

    public Usuario(String nombre, String edad, String correo, String password) {
        this.nombre = nombre;
        this.edad = edad;
        this.correo = correo;
        this.password = password;
    }

    // Constructor desde MongoDB
    public Usuario(Document doc) {
        this.nombre = doc.getString("nombre");
        this.edad = doc.getString("edad");
        this.correo = doc.getString("correo");
        this.password = doc.getString("password");
    }

    // Para guardar en MongoDB
    public Document toDocument() {
        return new Document("nombre", nombre)
                .append("edad", edad)
                .append("correo", correo)
                .append("password", password);
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public String getEdad() { return edad; }
    public String getCorreo() { return correo; }
    public String getPassword() { return password; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEdad(String edad) { this.edad = edad; }
    public void setCorreo(String correo) { this.correo = correo; }
    public void setPassword(String password) { this.password = password; }
}
