package Modelo;

import contracts.IProducto;
import org.bson.Document;

public class Celular implements IProducto {
    private String nombre;
    private String marca;
    private double precio;
    private String ram;
    private String almacenamiento;
    private String color;
    private String sim;

    public Celular(String nombre, String marca, double precio, String ram, String almacenamiento, String color, String sim) {
        this.nombre = nombre;
        this.marca = marca;
        this.precio = precio;
        this.ram = ram;
        this.almacenamiento = almacenamiento;
        this.color = color;
        this.sim = sim;
    }

    // Métodos de la interfaz IProducto (con @Override)
    @Override
    public String getNombre() {
        return this.nombre;
    }

    @Override
    public String getMarca() {
        return this.marca;
    }

    @Override
    public double getPrecio() {
        return this.precio;
    }

    @Override
    public String getRam() {
        return this.ram;
    }

    @Override
    public String getAlmacenamiento() {
        return this.almacenamiento;
    }

    @Override
    public String getColor() {
        return this.color;
    }

    @Override
    public String getSim() {
        return this.sim;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public void setAlmacenamiento(String almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSim(String sim) {
        this.sim = sim;
    }
    
    

    // Constructor para crear desde MongoDB
    public Celular(Document doc) {
        this.nombre = doc.getString("nombre");
        this.marca = doc.getString("marca");
        if (doc.get("precio") instanceof Number) {
            this.precio = doc.getDouble("precio");
        }
        this.ram = doc.getString("ram");
        this.almacenamiento = doc.getString("almacenamiento");
        this.color = doc.getString("color");
        this.sim = doc.getString("sim");
    }

    // Convertir a documento para MongoDB
    public Document toDocument() {
        return new Document("nombre", nombre)
                .append("marca", marca)
                .append("precio", precio)
                .append("ram", ram)
                .append("almacenamiento", almacenamiento)
                .append("color", color)
                .append("sim", sim);
    }

    @Override
    public String toString() {
        return nombre + " - " + marca + " - $" + precio;
    }
}