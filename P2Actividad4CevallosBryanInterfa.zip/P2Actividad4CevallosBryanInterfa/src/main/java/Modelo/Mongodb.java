package Modelo;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import contracts.IDataService; // Importa la nueva interfaz
import contracts.IProducto;

import javax.swing.JOptionPane;
import org.bson.conversions.Bson;

public class Mongodb implements IDataService { // Implementa la interfaz IDataService
    private MongoClient mongoClient;
    private MongoDatabase database;

    public Mongodb() {
        try {
            mongoClient = MongoClients.create("mongodb://localhost:27017");
            database = mongoClient.getDatabase("P2ProyectoTecnoMichi");
            System.out.println(" Conexion MongoDB exitosa a base: P2Proyecto");
        } catch (MongoException e) {
            System.out.println(" La conexion a MongoDB fallo: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error en la conexion a MongoDB.");
        }
    }

    @Override
    public MongoCollection<Document> getUsuariosCollection() {
        return database.getCollection("usuarios");
    }

    @Override
    public MongoCollection<Document> getCelularesCollection(){
        return database.getCollection("productos");
    }

    @Override
    public MongoCollection<Document> getComprasCollection() {
        return database.getCollection("compras");
    }

    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }

    @Override
    public void insertarCelular(Celular celular) {
        try {
            getCelularesCollection().insertOne(celular.toDocument());
            JOptionPane.showMessageDialog(null, "Celular guardado exitosamente.");
        } catch (MongoException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar celular: " + e.getMessage());
        }
    }

    @Override
    public void insertarUsuario(Usuario usuario) {
        try {
            getUsuariosCollection().insertOne(usuario.toDocument());
            JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente.");
        } catch (MongoException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar usuario: " + e.getMessage());
        }
    }
    
    @Override
public void insertarCompra(CarritoDeCompra carrito, String idUsuario) {
    try {
        Document compraDoc = new Document("id_usuario", idUsuario)
                                    .append("total", carrito.getPrecio())
                                    .append("productos", carrito.getProductosAsDocuments());
        getComprasCollection().insertOne(compraDoc);
        
        // --- AQUÍ ES DONDE SE ACTUALIZA EL STOCK ---
        for (IProducto producto : carrito.getProductos()) {
             // El método getCelularesCollection() ahora se usa para los productos
             Bson filtro = Filters.eq("nombre", producto.getNombre());
             Document productoEnBD = getCelularesCollection().find(filtro).first();
             if (productoEnBD != null) {
                int cantidadActual = productoEnBD.getInteger("cantidad", 0);
                int nuevaCantidad = cantidadActual - 1; // Se resta 1 por cada producto en el carrito
                getCelularesCollection().updateOne(filtro, Updates.set("cantidad", nuevaCantidad));
             }
        }

        JOptionPane.showMessageDialog(null, "Compra realizada exitosamente.");
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al registrar la compra: " + e.getMessage());
    }
}
}