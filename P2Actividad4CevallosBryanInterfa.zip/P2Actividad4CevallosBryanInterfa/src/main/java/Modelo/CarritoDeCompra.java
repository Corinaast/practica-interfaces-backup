package Modelo;

import contracts.IProducto;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

public class CarritoDeCompra implements IProducto {
    private List<IProducto> productos = new ArrayList<>();

    // No necesitas un constructor con parámetros
    public CarritoDeCompra() {
    }

    public void agregar(IProducto producto) {
        productos.add(producto);
    }

    public void eliminar(IProducto producto) {
        productos.remove(producto);
    }

    @Override
    public double getPrecio() {
        double total = 0;
        for (IProducto producto : productos) {
            total += producto.getPrecio();
        }
        return total;
    }

    @Override
    public String getNombre() {
        return "Carrito de Compras";
    }

    // Los siguientes métodos no son relevantes para un carrito,
    // pero deben ser implementados para cumplir con la interfaz.
    @Override
    public String getMarca() { return null; }
    @Override
    public String getRam() { return null; }
    @Override
    public String getAlmacenamiento() { return null; }
    @Override
    public String getColor() { return null; }
    @Override
    public String getSim() { return null; }
    
    // Nuevo método para obtener la lista de productos
    public List<IProducto> getProductos() {
        return productos;
    }
    
    // Método auxiliar para convertir los productos del carrito a una lista de Document
    public List<Document> getProductosAsDocuments() {
        List<Document> productosDocs = new ArrayList<>();
        for (IProducto producto : productos) {
            if (producto instanceof Celular) {
                productosDocs.add(((Celular) producto).toDocument());
            }
            // Aquí puedes agregar lógica para otros tipos de productos si los tuvieras (ej. Paquete)
        }
        return productosDocs;
    }
}