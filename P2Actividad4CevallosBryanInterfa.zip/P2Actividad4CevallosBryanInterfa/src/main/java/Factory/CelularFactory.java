package Factory;

import Modelo.Celular;
import contracts.IProductoFactory;

public class CelularFactory implements IProductoFactory {
    @Override
    public Celular crearProducto(
        String nombre,
        String marca,
        double precio,
        String ram,
        String almacenamiento,
        String color,
        String sim
    ) {
        // La fábrica crea el objeto Celular de forma centralizada
        return new Celular(nombre, marca, precio, ram, almacenamiento, color, sim);
    }
}