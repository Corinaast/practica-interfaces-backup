package Main;

import Controlador.ControladorUsuario;
import Modelo.Mongodb;
import Vista.VistaUsuario;
import contracts.IDataService;

public class P2Actividad {
    public static void main(String[] args) {
        // 1. Creamos una única instancia de la base de datos.
        // La almacenamos como Mongodb para poderla pasar a los controladores que la necesiten.
        Mongodb dataService = new Mongodb();

        // 2. Creamos la vista de usuario.
        VistaUsuario vistaUsuario = new VistaUsuario();

        // 3. Creamos el controlador de usuario, inyectando las dependencias.
        // Ahora el constructor de ControladorUsuario recibe la vista y la base de datos.
        ControladorUsuario controladorUsuario = new ControladorUsuario(vistaUsuario, dataService);

        // 4. Hacemos visible la ventana de inicio.
        vistaUsuario.setVisible(true);
        vistaUsuario.setLocationRelativeTo(null);
    }
}