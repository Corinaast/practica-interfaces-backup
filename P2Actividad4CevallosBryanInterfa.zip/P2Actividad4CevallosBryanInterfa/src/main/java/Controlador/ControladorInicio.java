package Controlador;

import Modelo.CarritoDeCompra;
import Vista.Inicio;
import Vista.Celulares;
import Vista.VistaCompra;
import Vista.VistaUsuario;
import Modelo.Mongodb;
import contracts.IDataService;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControladorInicio implements ActionListener {

    private Inicio vistaInicio;
    private IDataService dataService;
    private CarritoDeCompra carrito; // Ahora lo inicializamos en el constructor

    public ControladorInicio(Inicio vistaInicio, IDataService dataService) {
        this.vistaInicio = vistaInicio;
        this.dataService = dataService;
        this.carrito = new CarritoDeCompra(); // El carrito se crea al iniciar la sesión del usuario
        
        this.vistaInicio.ButtonCatalogo.addActionListener(this);
        this.vistaInicio.ButtonCompra.addActionListener(this);
        this.vistaInicio.ButtonCerrarSesionIni.addActionListener(this);
        this.vistaInicio.ButtonSalirUsu.addActionListener(this);
        this.vistaInicio.ButtonRegresoUsu.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaInicio.ButtonCatalogo) {
            abrirCatalogo();
        } else if (e.getSource() == vistaInicio.ButtonCompra) {
            abrirCompras();
        } else if (e.getSource() == vistaInicio.ButtonCerrarSesionIni || e.getSource() == vistaInicio.ButtonRegresoUsu) {
            cerrarSesion();
        } else if (e.getSource() == vistaInicio.ButtonSalirUsu) {
            salirAplicacion();
        }
    }

    private void abrirCatalogo() {
        Celulares vistaCelulares = new Celulares();
        // Pasamos la misma instancia de dataService y del carrito a la vista de Celulares
        ControladorCelulares controladorCelulares = new ControladorCelulares(vistaCelulares, dataService);
        vistaCelulares.setVisible(true);
        vistaInicio.dispose();
    }

    private void abrirCompras() {
        VistaCompra vistaCompra = new VistaCompra();
        // Pasamos la misma instancia de dataService y del carrito a la vista de Compra
        ControladorCompra controladorCompra = new ControladorCompra(vistaCompra, dataService, carrito);
        vistaCompra.setVisible(true);
        vistaInicio.dispose();
    }

    private void cerrarSesion() {
        VistaUsuario vistaUsuario = new VistaUsuario();
        ControladorUsuario controladorUsuario = new ControladorUsuario(vistaUsuario, (Mongodb) dataService);
        vistaUsuario.setVisible(true);
        vistaInicio.dispose();
    }

    private void salirAplicacion() {
        int confirm = JOptionPane.showConfirmDialog(vistaInicio, "¿Estás seguro de que quieres salir de la aplicación?", "Confirmar Salida", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            ((Mongodb) dataService).close();
            System.exit(0);
        }
    }
}