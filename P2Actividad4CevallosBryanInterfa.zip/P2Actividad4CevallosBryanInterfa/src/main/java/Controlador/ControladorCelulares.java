package Controlador;

import Modelo.Celular;
import Modelo.CarritoDeCompra;
import Modelo.Mongodb;
import Vista.Celulares;
import Vista.VistaCompra;
import Vista.Inicio;
import Vista.VistaUsuario;
import com.mongodb.client.MongoCursor;
import contracts.IDataService;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class ControladorCelulares implements ActionListener {

    private Celulares vistaCelulares;
    private IDataService dataService;
    private CarritoDeCompra carrito;

    public ControladorCelulares(Celulares vistaCelulares, IDataService dataService) {
        this.vistaCelulares = vistaCelulares;
        this.dataService = dataService;
        this.carrito = new CarritoDeCompra();
        
        inicializarListeners();
        cargarCatalogoCelulares();
    }
    
    private void inicializarListeners() {
        this.vistaCelulares.ButtonComprarCatal.addActionListener(this);
        this.vistaCelulares.ButtonAgregar.addActionListener(this);
        this.vistaCelulares.ButtonVerCarrito.addActionListener(this);
        this.vistaCelulares.ButtonBuscarCatal.addActionListener(this);
        this.vistaCelulares.ButtonRegresoIni.addActionListener(this);
        this.vistaCelulares.ButtonRegresoUsu.addActionListener(this);

        this.vistaCelulares.TableCatalogo.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cargarCelularSeleccionadoCatalogo();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaCelulares.ButtonComprarCatal) {
            compraRapida();
        } else if (e.getSource() == vistaCelulares.ButtonAgregar) {
            agregarACarrito();
        } else if (e.getSource() == vistaCelulares.ButtonVerCarrito) {
            verCarrito();
        } else if (e.getSource() == vistaCelulares.ButtonBuscarCatal) {
            buscarCelularesCatalogo();
        } else if (e.getSource() == vistaCelulares.ButtonRegresoIni) {
            regresarInicio();
        } else if (e.getSource() == vistaCelulares.ButtonRegresoUsu) {
            regresarUsuario();
        }
    }

    private Celular obtenerCelularDeFila(int fila) {
        String nombre = vistaCelulares.TableCatalogo.getValueAt(fila, 0).toString();
        String marca = vistaCelulares.TableCatalogo.getValueAt(fila, 1).toString();
        double precio = (Double) vistaCelulares.TableCatalogo.getValueAt(fila, 2);
        String ram = vistaCelulares.TableCatalogo.getValueAt(fila, 3).toString();
        String almacenamiento = vistaCelulares.TableCatalogo.getValueAt(fila, 4).toString();
        String color = vistaCelulares.TableCatalogo.getValueAt(fila, 5).toString();
        String sim = vistaCelulares.TableCatalogo.getValueAt(fila, 6).toString();
        return new Celular(nombre, marca, precio, ram, almacenamiento, color, sim);
    }
    
    public void compraRapida() {
        int fila = vistaCelulares.TableCatalogo.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(vistaCelulares, "Seleccione un celular para comprar rápidamente.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Celular celularSeleccionado = obtenerCelularDeFila(fila);

        CarritoDeCompra compraRapidaCarrito = new CarritoDeCompra();
        compraRapidaCarrito.agregar(celularSeleccionado);

        VistaCompra vistaCompra = new VistaCompra();
        ControladorCompra controladorCompra = new ControladorCompra(vistaCompra, dataService, compraRapidaCarrito);
        vistaCompra.setVisible(true);
        vistaCelulares.dispose();
    }
    
    public void agregarACarrito() {
    int fila = vistaCelulares.TableCatalogo.getSelectedRow();
    if (fila < 0) {
        JOptionPane.showMessageDialog(vistaCelulares, "Seleccione un celular para agregar al carrito.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        String nombreCelular = vistaCelulares.TableCatalogo.getValueAt(fila, 0).toString();
        int cantidadDisponible = (Integer) vistaCelulares.TableCatalogo.getValueAt(fila, 7);

        String cantidadStr = JOptionPane.showInputDialog(vistaCelulares, "¿Cuántos quiere agregar? (Disponible: " + cantidadDisponible + ")");
        if (cantidadStr == null || cantidadStr.trim().isEmpty()) {
            return;
        }
        
        int cantidadComprar = Integer.parseInt(cantidadStr.trim());
        
        if (cantidadComprar <= 0 || cantidadComprar > cantidadDisponible) {
            JOptionPane.showMessageDialog(vistaCelulares, "Cantidad inválida. Ingrese un valor entre 1 y " + cantidadDisponible, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Celular celularSeleccionado = obtenerCelularDeFila(fila);
        for (int i = 0; i < cantidadComprar; i++) {
            carrito.agregar(celularSeleccionado);
        }
        
        JOptionPane.showMessageDialog(vistaCelulares, cantidadComprar + " " + nombreCelular + " agregados al carrito.");

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(vistaCelulares, "Cantidad inválida. Por favor, ingrese un número.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
    }
}

    public void verCarrito() {
        if (carrito.getProductos().isEmpty()) {
            JOptionPane.showMessageDialog(vistaCelulares, "El carrito de compras está vacío.", "Carrito Vacío", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        VistaCompra vistaCompra = new VistaCompra();
        ControladorCompra controladorCompra = new ControladorCompra(vistaCompra, dataService, carrito);
        vistaCompra.setVisible(true);
        vistaCelulares.dispose();
    }
    
    public void cargarCatalogoCelulares() {
        DefaultTableModel modelo = (DefaultTableModel) vistaCelulares.TableCatalogo.getModel();
        modelo.setRowCount(0);

        try (MongoCursor<Document> cursor = dataService.getCelularesCollection().find().iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                modelo.addRow(new Object[]{
                    doc.getString("nombre"),
                    doc.getString("marca"),
                    doc.getDouble("precio"),
                    doc.getString("ram"),
                    doc.getString("almacenamiento"),
                    doc.getString("color"),
                    doc.getString("sim"),
                    doc.getInteger("cantidad", 0)
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vistaCelulares, "Error al cargar el catálogo de celulares: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarCelularesCatalogo() {
        DefaultTableModel modelo = (DefaultTableModel) vistaCelulares.TableCatalogo.getModel();
        modelo.setRowCount(0);

        Document filtro = new Document();

        String nombre = vistaCelulares.TextNombreCatal.getText().trim();
        String marca = vistaCelulares.TextMarcaCatal.getText().trim();
        String precioStr = vistaCelulares.TextPrecioCatal.getText().trim();
        String ram = (String) vistaCelulares.BoxRamCatal.getSelectedItem();
        String almacenamiento = (String) vistaCelulares.BoxAlmacenCatal.getSelectedItem();
        String color = (String) vistaCelulares.BoxColorCatal.getSelectedItem();
        String sim = "";

        if (vistaCelulares.RadioButtSim1Catal.isSelected()) {
            sim = "Sim 1";
        } else if (vistaCelulares.RadioButtSim2Catal.isSelected()) {
            sim = "Sim 2";
        }

        if (!nombre.isEmpty()) {
            filtro.append("nombre", new Document("$regex", nombre).append("$options", "i"));
        }
        if (!marca.isEmpty()) {
            filtro.append("marca", new Document("$regex", marca).append("$options", "i"));
        }
        if (!precioStr.isEmpty()) {
            try {
                double precio = Double.parseDouble(precioStr);
                filtro.append("precio", precio);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(vistaCelulares, "El precio debe ser un número válido.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        if (ram != null && !ram.isEmpty() && !ram.equals("1GB") && !ram.equals("2GB") && !ram.equals("4GB") && !ram.equals("8GB") && !ram.equals("12GB")) {
        } else if (ram != null && !ram.isEmpty()) {
            filtro.append("ram", ram);
        }

        if (almacenamiento != null && !almacenamiento.isEmpty() && !almacenamiento.equals("32GB") && !almacenamiento.equals("64GB") && !almacenamiento.equals("128GB") && !almacenamiento.equals("256GB")) {
        } else if (almacenamiento != null && !almacenamiento.isEmpty()) {
            filtro.append("almacenamiento", almacenamiento);
        }

        if (color != null && !color.isEmpty() && !color.equals("Negro") && !color.equals("Blanco") && !color.equals("Gris") && !color.equals("Dorado")) {
        } else if (color != null && !color.isEmpty()) {
            filtro.append("color", color);
        }

        if (!sim.isEmpty()) {
            filtro.append("sim", sim);
        }

        try (MongoCursor<Document> cursor = dataService.getCelularesCollection().find(filtro).iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                modelo.addRow(new Object[]{
                    doc.getString("nombre"),
                    doc.getString("marca"),
                    doc.getDouble("precio"),
                    doc.getString("ram"),
                    doc.getString("almacenamiento"),
                    doc.getString("color"),
                    doc.getString("sim"),
                    doc.getInteger("cantidad", 0)
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vistaCelulares, "Error al buscar celulares: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void cargarCelularSeleccionadoCatalogo() {
        int fila = vistaCelulares.TableCatalogo.getSelectedRow();
        if (fila >= 0) {
            vistaCelulares.TextNombreCatal.setText(vistaCelulares.TableCatalogo.getValueAt(fila, 0).toString());
            vistaCelulares.TextMarcaCatal.setText(vistaCelulares.TableCatalogo.getValueAt(fila, 1).toString());
            vistaCelulares.TextPrecioCatal.setText(vistaCelulares.TableCatalogo.getValueAt(fila, 2).toString());
            vistaCelulares.BoxRamCatal.setSelectedItem(vistaCelulares.TableCatalogo.getValueAt(fila, 3).toString());
            vistaCelulares.BoxAlmacenCatal.setSelectedItem(vistaCelulares.TableCatalogo.getValueAt(fila, 4).toString());
            vistaCelulares.BoxColorCatal.setSelectedItem(vistaCelulares.TableCatalogo.getValueAt(fila, 5).toString());

            String sim = vistaCelulares.TableCatalogo.getValueAt(fila, 6).toString();
            vistaCelulares.RadioButtSim1Catal.setSelected("Sim 1".equalsIgnoreCase(sim));
            vistaCelulares.RadioButtSim2Catal.setSelected("Sim 2".equalsIgnoreCase(sim));

            vistaCelulares.TextCantidadCatal.setText(vistaCelulares.TableCatalogo.getValueAt(fila, 7).toString());
        }
    }
    
    public void regresarInicio() {
        Inicio vistaInicio = new Inicio();
        ControladorInicio controladorInicio = new ControladorInicio(vistaInicio, (Mongodb) dataService);
        vistaInicio.setVisible(true);
        vistaCelulares.dispose();
    }

    public void regresarUsuario() {
        VistaUsuario vistaUsuario = new VistaUsuario();
        ControladorUsuario controladorUsuario = new ControladorUsuario(vistaUsuario, (Mongodb) dataService);
        vistaUsuario.setVisible(true);
        vistaCelulares.dispose();
    }

    // Método para limpiar los campos de búsqueda/selección en el catálogo
    public void limpiarCamposCatalogo() {
        vistaCelulares.TextNombreCatal.setText("");
        vistaCelulares.TextMarcaCatal.setText("");
        vistaCelulares.TextPrecioCatal.setText("");
        vistaCelulares.TextCantidadCatal.setText("");
        vistaCelulares.BoxRamCatal.setSelectedIndex(0);
        vistaCelulares.BoxAlmacenCatal.setSelectedIndex(0);
        vistaCelulares.BoxColorCatal.setSelectedIndex(0);
        vistaCelulares.buttonGroup1.clearSelection(); // Deseleccionar los RadioButtons
    }
}
