package Controlador;

import Modelo.CarritoDeCompra;
import Modelo.Celular;
import Modelo.Mongodb;
import Vista.VistaCompra;
import Vista.Celulares;
import contracts.IDataService;
import contracts.IProducto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorCompra implements ActionListener {
    
    private VistaCompra vistaCompra;
    private IDataService dataService;
    private CarritoDeCompra carrito;
    private String usuarioActual;

    public ControladorCompra(VistaCompra vistaCompra, IDataService dataService, CarritoDeCompra carrito) {
        this.vistaCompra = vistaCompra;
        this.dataService = dataService;
        this.carrito = carrito;
        this.usuarioActual = "UsuarioGenerico";

        inicializarListeners();
        cargarProductosEnTabla();
        actualizarTotal();
    }

    private void inicializarListeners() {
        this.vistaCompra.ButtonEliminarCompra.addActionListener(this);
        this.vistaCompra.ButtonComprar1.addActionListener(this);
        this.vistaCompra.ButtonRegresoIni.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaCompra.ButtonEliminarCompra) {
            eliminarDelCarrito();
        } else if (e.getSource() == vistaCompra.ButtonComprar1) {
            comprarCarrito();
        } else if (e.getSource() == vistaCompra.ButtonRegresoIni) {
            regresarCatalogo();
        }
    }

    private void cargarProductosEnTabla() {
    DefaultTableModel modelo = (DefaultTableModel) vistaCompra.TableCompra.getModel();
    modelo.setRowCount(0);

    // Using a Map to group products and count their quantities
    Map<String, Integer> productQuantities = new HashMap<>();
    Map<String, Celular> uniqueProducts = new HashMap<>();

    for (IProducto producto : carrito.getProductos()) {
        Celular celular = (Celular) producto;
        String nombre = celular.getNombre();

        // Increment quantity for existing products or add new one
        productQuantities.put(nombre, productQuantities.getOrDefault(nombre, 0) + 1);
        uniqueProducts.put(nombre, celular);
    }

    // Now, iterate through the unique products to populate the table
    for (Map.Entry<String, Integer> entry : productQuantities.entrySet()) {
        String nombre = entry.getKey();
        int cantidad = entry.getValue();
        Celular celular = uniqueProducts.get(nombre);
        double precioTotal = celular.getPrecio() * cantidad;
        
        modelo.addRow(new Object[]{
            celular.getNombre(),
            celular.getMarca(),
            celular.getPrecio(),
            cantidad, // Correctly show the aggregated quantity
            precioTotal // Correctly show the subtotal
        });
    }
}
    
    
    
    private void actualizarTotal() {
        double total = carrito.getPrecio();
        vistaCompra.TextTotal.setText(String.format("Total: $%.2f", total));
    }

    private void eliminarDelCarrito() {
        int fila = vistaCompra.TableCompra.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(vistaCompra, "Seleccione un producto para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        carrito.eliminar(carrito.getProductos().get(fila));
        JOptionPane.showMessageDialog(vistaCompra, "Producto eliminado del carrito.");
        
        cargarProductosEnTabla();
        actualizarTotal();
    }

    private void comprarCarrito() {
        if (carrito.getProductos().isEmpty()) {
            JOptionPane.showMessageDialog(vistaCompra, "El carrito está vacío. No hay nada para comprar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(vistaCompra, "¿Confirmar la compra por un total de $" + String.format("%.2f", carrito.getPrecio()) + "?", "Confirmar Compra", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.NO_OPTION) {
             return;
        }

        dataService.insertarCompra(carrito, usuarioActual);
        
        // --- NUEVA LÓGICA AGREGADA AQUÍ ---
        int seguirComprando = JOptionPane.showConfirmDialog(vistaCompra, "¿Desea seguir comprando?", "Continuar Compra", JOptionPane.YES_NO_OPTION);
        
        if (seguirComprando == JOptionPane.YES_OPTION) {
            regresarCatalogo();
        } else {
            System.exit(0);
        }
    }

    private void regresarCatalogo() {
        Celulares vistaCelulares = new Celulares();
        ControladorCelulares controladorCelulares = new ControladorCelulares(vistaCelulares, dataService);
        vistaCelulares.setVisible(true);
        vistaCompra.dispose();
    }
}