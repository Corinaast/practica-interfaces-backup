package Controlador;

import Modelo.Mongodb;
import Modelo.Usuario;
import Vista.Inicio;
import Vista.NewUsuario;
import Vista.Registro;
import Vista.VistaUsuario;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorUsuario implements ActionListener {

    private VistaUsuario vistaUsuario;
    private NewUsuario vistaNewUsuario;
    private Mongodb mongoDB;

    // Constructor para la vista de inicio de sesión (VistaUsuario.java)
    public ControladorUsuario(VistaUsuario vistaUsuario, Mongodb mongoDB) {
        this.vistaUsuario = vistaUsuario;
        this.mongoDB = mongoDB;
        // Asignar listeners a los botones de la vista de inicio de sesión
        this.vistaUsuario.ButtonIngresar.addActionListener(this);
        this.vistaUsuario.ButtonSinRegistro.addActionListener(this);
        this.vistaUsuario.buttonOlviPasswor.addActionListener(this);
    }

    // Constructor para la vista de nuevo usuario (NewUsuario.java)
    public ControladorUsuario(NewUsuario vistaNewUsuario, Mongodb mongoDB) {
        this.vistaNewUsuario = vistaNewUsuario;
        this.mongoDB = mongoDB;
        // Asignar listeners a los botones de la vista de nuevo usuario
        this.vistaNewUsuario.ButtonNewRegistro.addActionListener(this);
    }

    @Override
public void actionPerformed(ActionEvent e) {
    // Si el controlador se inicializó con la VistaUsuario (login)
    if (vistaUsuario != null) {
        if (e.getSource() == vistaUsuario.ButtonIngresar) {
            iniciarSesion();
        } else if (e.getSource() == vistaUsuario.ButtonSinRegistro) {
            abrirVentanaRegistro();
        } else if (e.getSource() == vistaUsuario.buttonOlviPasswor) {
            // Lógica para el botón de Olvidé mi contraseña
        }
    } 
    // Si el controlador se inicializó con la NewUsuario (registro)
    else if (vistaNewUsuario != null) {
        if (e.getSource() == vistaNewUsuario.ButtonNewRegistro) {
            registrarNuevoUsuario();
        }
    }
}

    /**
     * Verifica si la colección de usuarios está vacía y, si es así, crea usuarios predeterminados.
     */
    private void checkAndCreateInitialUsers() {
        // ... El resto de este método está bien, no lo modificamos
    }

    private void iniciarSesion() {
        String nombre = vistaUsuario.TextNombre.getText();
        String password = new String(vistaUsuario.Password.getPassword());

        if (nombre.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(vistaUsuario, "Por favor, ingrese nombre y contraseña.", "Campos Vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        MongoCollection<Document> collection = mongoDB.getUsuariosCollection();
        Document userDoc = collection.find(Filters.and(
                Filters.eq("nombre", nombre),
                Filters.eq("password", password)
        )).first();

        if (userDoc != null) {
            JOptionPane.showMessageDialog(vistaUsuario, "Inicio de sesión exitoso. ¡Bienvenido " + nombre + "!", "Bienvenido", JOptionPane.INFORMATION_MESSAGE);
            String rol = userDoc.getString("rol");

            if ("ADMIN".equalsIgnoreCase(rol)) {
                Vista.Registro vistaRegistro = new Vista.Registro();
                ControladorRegistro controladorRegistro = new ControladorRegistro(vistaRegistro, mongoDB);
                controladorRegistro.inicializar(); // <<-- AQUÍ ESTÁ LA CORRECCIÓN CLAVE
                vistaRegistro.setVisible(true);
            } else if ("COMPRADOR".equalsIgnoreCase(rol)) {
                Inicio vistaInicio = new Inicio();
                ControladorInicio controladorInicio = new ControladorInicio(vistaInicio, mongoDB);
                vistaInicio.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(vistaUsuario, "Rol de usuario no reconocido.", "Error de Rol", JOptionPane.ERROR_MESSAGE);
                return;
            }
            vistaUsuario.dispose();
        } else {
            JOptionPane.showMessageDialog(vistaUsuario, "Nombre de usuario o contraseña incorrectos.", "Error de Credenciales", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void abrirVentanaRegistro() {
        NewUsuario newUsuario = new NewUsuario();
        ControladorUsuario controladorNewUsuario = new ControladorUsuario(newUsuario, mongoDB); // <<-- CORREGIDO
        newUsuario.setVisible(true);
        vistaUsuario.dispose();
    }

    
    private void registrarNuevoUsuario() {
        String nombre = vistaNewUsuario.TextNombre1.getText();
        String edad = vistaNewUsuario.TextEdad1.getText();
        String correo = vistaNewUsuario.TextCorreo.getText();
        String password = new String(vistaNewUsuario.NewPassword.getPassword());

        if (nombre.isEmpty() || edad.isEmpty() || correo.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(vistaNewUsuario, "Por favor, complete todos los campos.", "Campos Vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        MongoCollection<Document> collection = mongoDB.getUsuariosCollection();
        
        // Verificar si el nombre de usuario ya existe
        Document existingUserByName = collection.find(Filters.eq("nombre", nombre)).first();
        if (existingUserByName != null) {
            JOptionPane.showMessageDialog(vistaNewUsuario, "El nombre de usuario ya existe. Por favor, elija otro.", "Usuario Existente", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Verificar si el correo ya existe
        Document existingUserByEmail = collection.find(Filters.eq("correo", correo)).first();
        if (existingUserByEmail != null) {
            JOptionPane.showMessageDialog(vistaNewUsuario, "El correo electrónico ya está registrado.", "Correo Existente", JOptionPane.WARNING_MESSAGE);
            return;
        }

       Usuario nuevoUsuario = new Usuario(nombre, edad, correo, password);
    Document newUserDoc = nuevoUsuario.toDocument();
    newUserDoc.append("rol", "COMPRADOR");
    
    try {
        collection.insertOne(newUserDoc);
        JOptionPane.showMessageDialog(vistaNewUsuario, "Usuario registrado con éxito. Ahora puede iniciar sesión.", "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);
        
        // Redirigir a la pantalla de inicio de sesión
        VistaUsuario loginView = new VistaUsuario();
        ControladorUsuario loginController = new ControladorUsuario(loginView, mongoDB);
        loginView.setVisible(true);
        vistaNewUsuario.dispose();
    } catch (Exception e) {
        // <<-- AQUÍ ESTÁ LA CORRECCIÓN CLAVE
        // Usa vistaNewUsuario para mostrar el error
        JOptionPane.showMessageDialog(vistaNewUsuario, "Error al registrar usuario: " + e.getMessage(), "Error de Registro", JOptionPane.ERROR_MESSAGE);
    }
}
}
