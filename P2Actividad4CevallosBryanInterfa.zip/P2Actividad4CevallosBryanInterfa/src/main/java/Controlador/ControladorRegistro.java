package Controlador;

import Modelo.Celular;
import Modelo.Mongodb;
import Vista.Registro;
import Vista.VistaUsuario;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
import org.bson.types.ObjectId;
import contracts.IDataService;
import command.ICommand;
import command.AgregarCelularCommand;
import command.EditarCelularCommand;
import command.EliminarCelularCommand;
import command.Caretaker;
import Factory.CelularFactory; // Importa la clase de la fábrica
import Modelo.Paquete;
import contracts.IProducto;
import contracts.IProductoFactory; // Importa la interfaz de la fábrica

public class ControladorRegistro implements ActionListener {
    private Registro vistaRegistro;
    private IDataService dataService;
    private IProductoFactory celularFactory;
    private Caretaker caretaker = new Caretaker();

    // El constructor SÓLO debe inicializar la clase
    public ControladorRegistro(Registro vista, IDataService dataService) {
        this.vistaRegistro = vista;
        this.dataService = dataService;
        this.celularFactory = new CelularFactory();
    }

    // Nuevo método para inicializar listeners y cargar datos
    public void inicializar() {
        // Asignar listeners a los botones y tabla de la vista de Registro
        this.vistaRegistro.ButtonAgregarRegi.addActionListener(this);
        this.vistaRegistro.ButtonEditarReg.addActionListener(this);
        this.vistaRegistro.ButtonEliminarReg.addActionListener(this);
        this.vistaRegistro.ButtonBuscarReg.addActionListener(this);
        this.vistaRegistro.ButtonCerraSesion.addActionListener(this);
        this.vistaRegistro.ButtonUndo.addActionListener(this);
        this.vistaRegistro.ButtonRedo.addActionListener(this);
        
        this.vistaRegistro.TableRegistro.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cargarCelularSeleccionado(); // Cambiado a cargar solo el seleccionado
            }
        });
        
        // Cargar los celulares en la tabla al iniciar la vista
        cargarCelularesEnTabla();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaRegistro.ButtonAgregarRegi) {
            ejecutarAgregarCelular();
        } else if (e.getSource() == vistaRegistro.ButtonEditarReg) {
            ejecutarModificarCelular();
        } else if (e.getSource() == vistaRegistro.ButtonEliminarReg) {
            ejecutarEliminarCelular();
        } else if (e.getSource() == vistaRegistro.ButtonBuscarReg) {
            buscarCelulares();
        } else if (e.getSource() == vistaRegistro.ButtonCerraSesion) {
            cerrarSesion();
        } else if (e.getSource() == vistaRegistro.ButtonUndo) {
            caretaker.undo();
            cargarCelularesEnTabla();
        } else if (e.getSource() == vistaRegistro.ButtonRedo) {
            caretaker.redo();
            cargarCelularesEnTabla();
        }
    }

    // Métodos refactorizados para usar el patrón Command
    public void ejecutarAgregarCelular() {
        try {
            Celular nuevoCelular = celularFactory.crearProducto(
                vistaRegistro.TextNombre.getText(),
                vistaRegistro.TextMarca.getText(),
                Double.parseDouble(vistaRegistro.TextPrecio1.getText()),
                (String) vistaRegistro.BoxRamRegistro.getSelectedItem(),
                (String) vistaRegistro.BoxAlmacenRegi.getSelectedItem(),
                (String) vistaRegistro.BoxColorRegi.getSelectedItem(),
                vistaRegistro.RadioButtSin1Regi.isSelected() ? "Sim 1" : "Sim 2"
            );
            
            int cantidad = Integer.parseInt(vistaRegistro.TextCantidad.getText());

            ICommand command = new AgregarCelularCommand(dataService, nuevoCelular, cantidad);
            caretaker.executeCommand(command);

            JOptionPane.showMessageDialog(vistaRegistro, "Celular agregado exitosamente.");
            limpiarCamposCelular();
            cargarCelularesEnTabla();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vistaRegistro, "Error en el formato de datos. Precio y cantidad deben ser números.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void ejecutarModificarCelular() {
        int fila = vistaRegistro.TableRegistro.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(vistaRegistro, "Seleccione un celular para modificar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            ObjectId id = (ObjectId) vistaRegistro.TableRegistro.getValueAt(fila, 0);

            Celular celularModificado = celularFactory.crearProducto(
                vistaRegistro.TextNombre.getText(),
                vistaRegistro.TextMarca.getText(),
                Double.parseDouble(vistaRegistro.TextPrecio1.getText()),
                (String) vistaRegistro.BoxRamRegistro.getSelectedItem(),
                (String) vistaRegistro.BoxAlmacenRegi.getSelectedItem(),
                (String) vistaRegistro.BoxColorRegi.getSelectedItem(),
                vistaRegistro.RadioButtSin1Regi.isSelected() ? "Sim 1" : "Sim 2"
            );
            int cantidad = Integer.parseInt(vistaRegistro.TextCantidad.getText());

            ICommand command = new EditarCelularCommand(dataService, id, celularModificado, cantidad);
            caretaker.executeCommand(command);
            
            JOptionPane.showMessageDialog(vistaRegistro, "Celular modificado exitosamente.");
            limpiarCamposCelular();
            cargarCelularesEnTabla();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vistaRegistro, "Error en el formato de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void ejecutarEliminarCelular() {
        int fila = vistaRegistro.TableRegistro.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(vistaRegistro, "Seleccione un celular para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(vistaRegistro, "¿Está seguro de que desea eliminar este celular?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                ObjectId id = (ObjectId) vistaRegistro.TableRegistro.getValueAt(fila, 0);

                ICommand command = new EliminarCelularCommand(dataService, id);
                caretaker.executeCommand(command);
                
                JOptionPane.showMessageDialog(vistaRegistro, "Celular eliminado exitosamente.");
                limpiarCamposCelular();
                cargarCelularesEnTabla();
            } catch (ClassCastException e) {
                JOptionPane.showMessageDialog(vistaRegistro, "Error al obtener el ID del celular.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Métodos auxiliares
    public void cargarCelularesEnTabla() {
        DefaultTableModel modelo = (DefaultTableModel) vistaRegistro.TableRegistro.getModel();
        modelo.setRowCount(0);

        try (MongoCursor<Document> cursor = dataService.getCelularesCollection().find().iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                modelo.addRow(new Object[]{
                    doc.getObjectId("_id"),
                    doc.getString("nombre"),
                    doc.getString("marca"),
                    doc.getDouble("precio"),
                    doc.getString("ram"),
                    doc.getString("almacenamiento"),
                    doc.getString("color"),
                    doc.getString("sim"),
                    doc.getInteger("cantidad", 0)
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vistaRegistro, "Error al cargar celulares: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void cargarCelularSeleccionado() {
        int fila = vistaRegistro.TableRegistro.getSelectedRow();
        if (fila >= 0) {
            vistaRegistro.TextNombre.setText(vistaRegistro.TableRegistro.getValueAt(fila, 1).toString());
            vistaRegistro.TextMarca.setText(vistaRegistro.TableRegistro.getValueAt(fila, 2).toString());
            vistaRegistro.TextPrecio1.setText(vistaRegistro.TableRegistro.getValueAt(fila, 3).toString());
            vistaRegistro.BoxRamRegistro.setSelectedItem(vistaRegistro.TableRegistro.getValueAt(fila, 4).toString());
            vistaRegistro.BoxAlmacenRegi.setSelectedItem(vistaRegistro.TableRegistro.getValueAt(fila, 5).toString());
            vistaRegistro.BoxColorRegi.setSelectedItem(vistaRegistro.TableRegistro.getValueAt(fila, 6).toString());

            String sim = vistaRegistro.TableRegistro.getValueAt(fila, 7).toString();
            vistaRegistro.RadioButtSin1Regi.setSelected("Sim 1".equalsIgnoreCase(sim));
            vistaRegistro.RadioButtSim2Regi.setSelected("Sim 2".equalsIgnoreCase(sim));

            vistaRegistro.TextCantidad.setText(vistaRegistro.TableRegistro.getValueAt(fila, 8).toString());
        }
    }

    public void buscarCelulares() {
        DefaultTableModel modelo = (DefaultTableModel) vistaRegistro.TableRegistro.getModel();
        modelo.setRowCount(0);

        String nombreBusqueda = vistaRegistro.TextBuscarNombreReg.getText().trim();
        Document filtro = new Document();

        if (!nombreBusqueda.isEmpty()) {
            filtro.append("nombre", new Document("$regex", nombreBusqueda).append("$options", "i"));
        }

        try (MongoCursor<Document> cursor = dataService.getCelularesCollection().find(filtro).iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                modelo.addRow(new Object[]{
                    doc.getObjectId("_id"),
                    doc.getString("nombre"),
                    doc.getString("marca"),
                    doc.getDouble("precio"),
                    doc.getString("ram"),
                    doc.getString("almacenamiento"),
                    doc.getString("color"),
                    doc.getString("sim"),
                    doc.getInteger("cantidad", 0)
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vistaRegistro, "Error al buscar celulares: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void limpiarCamposCelular() {
        vistaRegistro.TextCantidad.setText("");
        vistaRegistro.TextNombre.setText("");
        vistaRegistro.TextMarca.setText("");
        vistaRegistro.TextPrecio1.setText("");
        vistaRegistro.BoxRamRegistro.setSelectedIndex(0);
        vistaRegistro.BoxAlmacenRegi.setSelectedIndex(0);
        vistaRegistro.BoxColorRegi.setSelectedIndex(0);
        vistaRegistro.RadioButtSin1Regi.setSelected(false);
        vistaRegistro.RadioButtSim2Regi.setSelected(false);
        vistaRegistro.TextBuscarNombreReg.setText("");
    }
    
    // Archivo: Controlador/ControladorRegistro.java
public void cerrarSesion() {
    vistaRegistro.dispose(); // Cierra la ventana de registro

    // Crea una nueva instancia de la vista de usuario
    VistaUsuario vistaUsuario = new VistaUsuario();

    // Crea una nueva instancia del controlador de usuario, pasándole la vista y la instancia de MongoDB
    ControladorUsuario controladorUsuario = new ControladorUsuario(vistaUsuario, (Mongodb) dataService);

    // Hace visible la ventana de usuario
    vistaUsuario.setVisible(true);
}
    
}